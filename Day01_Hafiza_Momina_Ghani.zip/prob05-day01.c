#include<stdio.h>
int main()
{
	printf("|H|\t    |H|  |E||E||E||E| |L|\t   |L|\t \t |O||O||O||O||O|");
	printf("\n|H|\t    |H|  |E|\t      |L|\t   |L|\t  \t|O|\t      |O|");
	printf("\n|H|\t    |H|  |E|\t      |L|\t   |L|\t  \t|O|\t      |O|");
	printf("\n|H|\t    |H|  |E|\t      |L|\t   |L|\t  \t|O|\t      |O|");
	printf("\n|H||H||H||H||H|  |E||E||E|    |L|\t   |L|\t\t|O|\t      |O|");
	printf("\n|H|\t    |H|  |E|\t      |L|\t   |L|\t  \t|O|\t      |O|");
	printf("\n|H|\t    |H|  |E|\t      |L|\t   |L|\t  \t|O|\t      |O|");
	printf("\n|H|\t    |H|  |E|\t      |L|\t   |L|\t  \t|O|\t      |O|");
	printf("\n|H|\t    |H|  |E||E||E||E| |L||L||L||L| |L||L||L||L|\t |O||O||O||O||O|");
	return 0; 
}
