#include<stdio.h>
int main()
{
	printf(" _____\n|_____\n|_____");
	return 0;
}
