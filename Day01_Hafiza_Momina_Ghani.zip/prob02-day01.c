#include<stdio.h>
int main()
{
	printf("This is Master in'C language'30 days course.\nThis course is organized by TECH INVOLVERS.");
	return 0;
}
